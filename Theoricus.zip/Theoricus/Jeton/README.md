magento2-jeton
======================

Jeton payment gateway Magento2 extension

Install
=======

1. Upload code to folder app/code/Theoricus/Jeton

2.  Enter following commands to install module:
    php bin/magento setup:upgrade
    php bin/magento setup:static-content:deploy

4. Enable and configure Jeton in Magento Admin under Stores -> Configuration-> Sales -> Payment Methods -> Jeton
