<?php
namespace Theoricus\Jeton\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    public $resource = '';
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\ResourceConnection $resource
    ) {
        parent::__construct($context);
        $this->resource = $resource;
    }
    
    public function getTransaction($order_id)
    {
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('jeton_order');
        $query = "select response from {$tableName} where order_id=".(int)($order_id);
        return $connection->fetchOne($query);
    }
    
    public function getTransactionByPaymentId($payment_id, $column)
    {
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('jeton_order');
        $query = "select {$column} from {$tableName} where payment_id='".addslashes(strip_tags($payment_id))."'";
        return $connection->fetchOne($query);
    }
    
    public function updateTransaction($order_id, $payment_id, $response='')
    {
        $connection = $this->resource->getConnection();
        $tableName = $this->resource->getTableName('jeton_order');
        
        $transaction = $this->getTransaction($order_id);
        if ($transaction) {
            $connection->update(
                $tableName, 
                [ 'response' => $response],
                "order_id=".$order_id    
            );
        } else {
            $connection->insert(
                $tableName, 
                ['response' => $response, 'order_id' => $order_id, 'payment_id' => $payment_id]
            );
        }
    }
}
