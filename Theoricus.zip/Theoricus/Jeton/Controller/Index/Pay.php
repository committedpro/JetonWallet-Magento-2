<?php
namespace Theoricus\Jeton\Controller\Index;

class Pay extends \Magento\Framework\App\Action\Action
{
    protected $helper;
    protected $payment;
    protected $orderFactory;

    public function __construct(
        \Theoricus\Jeton\Helper\Data $helper,
        \Theoricus\Jeton\Model\Pay $payment,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\App\Action\Context $context
    ) {
        $this->helper = $helper;
        $this->payment = $payment;
        $this->orderFactory = $orderFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $model = $this->_objectManager->get('Theoricus\Jeton\Model\Pay');
        $order = $model->getOrder();
        if ($order && $order->getId() > 0) {

            $params = array(
                "orderId" => $order->getIncrementId(),
                "amount" => $this->getFormattedAmount($order->getGrandTotal()),
                "currency" => $order->getStoreCurrencyCode(),
                "method" => "CHECKOUT",
                "returnUrl" => $model->getCallbackUrl()
            );
            
            $header = array(
                "Content-Type: application/json",
                "X-API-KEY: ".$model->getConfigValue('api_key')
            );
            
            
            $apiUrl = $model->getApiUrl().'pay';
            
            $error = false;
            $message = '';
            
            $model->log('Request:');
            $model->log(json_encode($params));
            $model->log($apiUrl);
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            $result = curl_exec($ch);

            if (curl_errno($ch)) { 
                $error = true;
                $message = curl_error($ch);
                curl_close($ch);
            } else {
                curl_close($ch);
                
                $model->log('Response:');
                $model->log($result);
                
                $response = json_decode($result, true);

                if (!isset($response['message'])) {
                    $transaction_id = $response['paymentId'];
                    $redirectUrl = $response['checkout'];

                    if (!empty($transaction_id)) {
                        $this->helper->updateTransaction($order->getId(), $transaction_id, $result);
                    }
                    echo '<script>window.top.location.href = "'.$redirectUrl.'";</script>';
                    exit;
                } else {
                    $error = true;
                    $message = $response['message'];
                }
            }
            
            if ($error) {
                $url = $model->getCancelUrl().'?message='.$message;
		        echo '<script>window.top.location.href = "'.$url.'";</script>';
                exit;
            }
        } else {
            $this->_redirect('checkout/cart');
        }
    }
    
    public function getFormattedAmount($amount)
    {
        return round($amount, 2);
    }
}
