<?php

namespace Theoricus\Jeton\Controller\Index;

use Magento\Checkout\Model\Type\Onepage;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Quote\Api\CartManagementInterface;

class Cancel extends \Magento\Framework\App\Action\Action {

    /**
     * @var \Magento\Quote\Api\CartManagementInterface
     */
    protected $cartManagement;

    /**
     * @var \Magento\Framework\Event\ManagerInterface
     */
    protected $eventManager;

    /**
     * @var \Magento\Checkout\Model\Type\Onepage
     */
    protected $onepageCheckout;

    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var \Magento\Authorizenet\Helper\DataFactory
     */
    protected $dataFactory;

    /**
     *
     * @var \Magento\Checkout\Model\Session
     */
    protected $session;

    /**
     *
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $orderFactory;

    /**
     *
     * @var Magento\Checkout\Model\Session
     */
    protected $_order;

    /**
     * 
     * @param Context $context
     * @param \Magento\Checkout\Model\Session $orderSession
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Checkout\Model\Session $session
     * @param Registry $coreRegistry
     * @param CartManagementInterface $cartManagement
     * @param Onepage $onepageCheckout
     */
    public function __construct(
        Context $context, 
        \Magento\Checkout\Model\Session $orderSession, 
        \Magento\Sales\Model\OrderFactory $orderFactory, 
        \Magento\Checkout\Model\Session $session, 
        Registry $coreRegistry, 
        CartManagementInterface $cartManagement, 
        Onepage $onepageCheckout
    ) {
        $this->eventManager = $context->getEventManager();
        $this->cartManagement = $cartManagement;
        $this->onepageCheckout = $onepageCheckout;
        $this->_coreRegistry = $coreRegistry;
        $this->session = $session;
        $this->orderFactory = $orderFactory;
        $this->_order = $orderSession;
        parent::__construct($context);
    }

    /**
     *
     * @return string
     */
    public function execute() {
        $order = $this->getOrder();
        $order->cancel();
		
        $message = $this->getRequest()->getParam('message');
        if (!$message) {
            $message = __('Order Canceled by Customer');
        }
		$message = __('Payment Failed with Jeton. Reason: '.$message);
		
        $order->addStatusHistoryComment('Order Canceled', \Magento\Sales\Model\Order::STATE_CANCELED);
        $order->save();
        $this->session->restoreQuote();
	    $this->messageManager->addError($message);
        $this->_redirect('checkout/cart');
    }

    public function getOrder()
    {
        $incrementId = $this->getCheckout()->getLastRealOrderId();
        $orderFactory = $this->orderFactory->create();
        return $orderFactory->loadByIncrementId($incrementId);
    }

    /**
     * Get Checkout Session
     * @return \Magento\Checkout\Model\Session
     */
    public function getCheckout()
    {
        return $this->_order;
    }
}
