<?php
namespace Theoricus\Jeton\Controller\Index;

use Magento\Framework\Controller\ResultFactory;

class Callback extends \Magento\Framework\App\Action\Action
{
    protected $helper;
    protected $payment;
    protected $orderFactory;

    public function __construct(
        \Theoricus\Jeton\Helper\Data $helper,
        \Theoricus\Jeton\Model\Pay $payment,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Framework\App\Action\Context $context
    ) {
        $this->helper = $helper;
        $this->payment = $payment;
        $this->orderFactory = $orderFactory;
        parent::__construct($context);
    }

    public function execute()
    {
        $params = $this->getRequest()->getParams();
        
        $model = $this->_objectManager->get('Theoricus\Jeton\Model\Pay');
        $session = $this->_objectManager->get('Magento\Checkout\Model\Session');
        
        $error = false;
        $message = '';
        $additional_comment = '';

        if (isset($params['paymentId']) && !empty($params['paymentId'])) {
            $payment_id = $params['paymentId'];

            $order_id = $this->helper->getTransactionByPaymentId($payment_id, 'order_id');
            $order = $this->getOrder($order_id);
            
            $params = array(
                "paymentId" => $payment_id,
                "type" => "PAY",
            );
            
            $header = array(
                "Content-Type: application/json",
                "X-API-KEY: ".$model->getConfigValue('api_key')
            );

            $apiUrl = $model->getApiUrl().'detail';

            $model->log('Request:');
            $model->log(json_encode($params));
            $model->log($apiUrl);
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($params));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            $result = curl_exec($ch);

            if (curl_errno($ch)) { 
                $error = true;
                $message = curl_error($ch);
                curl_close($ch);
            } else {
                curl_close($ch);
                
                $model->log('Response:');
                $model->log($result);
                
                $response = json_decode($result, true);

                if (isset($response['status']) && $response['status'] == 'SUCCESS') {
                    $transaction_id = $response['paymentId'];
                    $this->helper->updateTransaction($order->getId(), $transaction_id, $result);

                    $comment = __('Payment successful with Jeton.');
                    $comment .= __('Payment ID: '). $transaction_id;

                    $state = $model->getConfigValue('new_order_status');
                    if (empty($state)) {
                        $state = \Magento\Sales\Model\Order::STATE_PROCESSING;
                    }
                    $status = $state;

                    $order->setState($state);
                    $order->setStatus($status);
                    $order->setTotalPaid($order->getGrandTotal());
                    $order->addStatusHistoryComment($comment, $status);
                    $order->save();
                    
                    echo '<script>window.top.location.href = "'.$model->getCheckoutSuccessUrl().'";</script>';
                    exit;
                } else {
                    $error = true;
                    $message = $response['message'];
                }
            }
            
        } else {
            $error = true;
            $message = 'Payment Id Empty';
        }
        
        if ($error) {
            
            if ($order && $order->getId() > 0) {
                $order->cancel();
                $message = __('Payment Failed with Jeton. Reason: '.$message);
                $order->addStatusHistoryComment($message.' '.$additional_comment, \Magento\Sales\Model\Order::STATE_CANCELED);
                $order->save();
            }
            
            if ($session) {
                $session->restoreQuote();
            }
            
            $this->messageManager->addError($message);
            echo '<script>window.top.location.href = "'.$model->getCheckoutCartUrl().'";</script>';
        }
        exit;
    }
    
    public function getOrder($Id)
    {
        $orderFactory = $this->orderFactory->create();
        return $orderFactory->load($Id);
    }
    
    public function getOrderByIncrementId($Id)
    {
        $orderFactory = $this->orderFactory->create();
        return $orderFactory->loadByIncrementId($Id);
    }
    
    public function getFormattedAmount($amount)
    {
        return round($amount, 2);
    }
}
